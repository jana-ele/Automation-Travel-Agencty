package com.ata.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ata.model.Vehicle;
import com.ata.repository.VehicleRepo;


@Service
public class VehicleServiceImpl  {
	@Autowired
	private VehicleRepo vehicleRepo;
	
	
	public String addVehicle(Vehicle v) {
		vehicleRepo.saveAndFlush(v);
		return "Vehicle added";
		
	}
	
	public List<Vehicle> showVehicle(){
	return 	vehicleRepo.findAll();
		
	}
	
	public boolean deleteVehicleId(int id) {
		if(vehicleRepo.existsById(id)==true) {
			vehicleRepo.deleteById(id);
			return true;
		}else {	
			return false;
		}
	}

	public String updateVehicleId(Vehicle v) {
		vehicleRepo.saveAndFlush(v);
		return "Vehicle updated";
	}
	
	public Vehicle getVehicleById(int id) {
		return vehicleRepo.findById(id).get();
	}

}
