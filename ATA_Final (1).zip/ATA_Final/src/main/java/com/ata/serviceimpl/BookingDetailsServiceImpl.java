package com.ata.serviceimpl;

import java.util.List;

import javax.websocket.server.ServerEndpoint;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ata.model.BookingDetails;
import com.ata.repository.BookingDetailsRepo;

@Service
public class BookingDetailsServiceImpl {
	
	
	@Autowired
	BookingDetailsRepo repo;

	
	
	public List<BookingDetails> getAllBookings(){
		return repo.findAll();
	}
	
}
