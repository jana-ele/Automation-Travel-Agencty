package com.ata.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.ata.model.BookingDetails;
import com.ata.model.Vehicle;
import com.ata.serviceimpl.BookingDetailsServiceImpl;
import com.ata.serviceimpl.VehicleServiceImpl;

@Controller
public class JspController {
	
	@Autowired
	VehicleServiceImpl vImpl;
	
	@Autowired
	BookingDetailsServiceImpl bImpl;
	
	
	@RequestMapping(value = "/" ,  method = RequestMethod.GET)
	public String getHome() {
		
		return "Home";
	}
	@GetMapping("ulogin")
	public String login() {
		return "Loginpage";
	}
	
	@GetMapping("/show")
	public String showAllVehicle( Model mod) {
		List<Vehicle>l=vImpl.showVehicle();
		mod.addAttribute("w",l);
		return "vehicledata";
	}
	
	@GetMapping("/add")
	public String getpage(Model m) {
		m.addAttribute("msg", "Add");
		return "add";
	}
	
	@GetMapping("/update")
	public String getupdatepage(@RequestParam Integer vid,Model m) {
		Vehicle veh = vImpl.getVehicleById(vid);
		m.addAttribute("veh", veh);
		m.addAttribute("msg", "Update");
		return "add";
	}
	
	@GetMapping("/del")
	public String getdeletepage(ModelMap map,@RequestParam Integer vid) {
		map.put("err", "");
		vImpl.deleteVehicleId(vid);
		return "redirect:/show";
	}
	
	
	@PostMapping("login")
	public String loginpage(ModelMap model, @RequestParam  String username, @RequestParam String password) {
		if(username.equals("Admin@123") && password.equals("Admin@123"))
			return "option";
		else
			model.put("wrong", "Invalid credentials");
		return "Loginpage";
	}
	
	
	
	
	@PostMapping("/deletesend")
	public String deleteSucess(@RequestParam("id") int id, ModelMap map) {
//		vImpl.deleteVehicleId(id);
		if(!vImpl.deleteVehicleId(id)) {
			map.put("err", "Id does not exists");
			return "delete";
		}
		
		
		return "redirect:/show";
	}
	
	
	@RequestMapping(value = "/addvehicle" ,  method = RequestMethod.POST)
	public String addData(Vehicle vehi) {
		vImpl.addVehicle(vehi);
		return "redirect:/show";
	}
	
	@RequestMapping(value = "/updatevehicle/{id}" ,  method = RequestMethod.GET)
	public String updateData(@PathVariable("id") int id, Model mod) {
		
		mod.addAttribute("uv",vImpl.getVehicleById(id));
		System.out.println(vImpl.getVehicleById(id));
//		return "update";
		return "redirect:/show";
	}
	
	@RequestMapping(value = "/delvehicle/{id}" ,  method = RequestMethod.POST)
	public String deleteData(@PathVariable("id") int id) {
		System.out.println("Delete "+id);
		vImpl.deleteVehicleId(id);
		
		return "vehicledata";
	}
	
	
	@GetMapping("/showbookingdetails")
	public String getAllDetails(Model mod) {
		
		mod.addAttribute("w",bImpl.getAllBookings());
		return "bookingdetails";
	}
	
	@GetMapping("/logout")
	public String logout() {
		return "Home";
	}
	@GetMapping("back1")
	public String back1() {
		return "option";
	}
}
