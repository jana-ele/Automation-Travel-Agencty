package com.ata;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AutomationofTravelAgencyFinalApplication {

	public static void main(String[] args) {
		SpringApplication.run(AutomationofTravelAgencyFinalApplication.class, args);
		System.out.println("Hello");
	}

}
