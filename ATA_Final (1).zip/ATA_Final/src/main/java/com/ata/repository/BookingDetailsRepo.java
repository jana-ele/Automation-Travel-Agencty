package com.ata.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ata.model.BookingDetails;


@Repository
public interface BookingDetailsRepo  extends JpaRepository<BookingDetails, Integer>{

}
