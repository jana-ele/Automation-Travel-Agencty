package com.ata.model;

import java.time.LocalDate;
import java.util.Date;

import javax.annotation.Generated;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;


@Entity
public class BookingDetails {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer reservationID;
	private String customerDetails;
	private String routeDetails;
	private LocalDate bookingDate;
	private LocalDate journeyDate;
	private String vehicleDetails;
	private String driverDetails;
	private String bookingStatus;
	private double totalFare;
	private String boardingPoint;
	private String dropPoint;
	public Integer getReservationID() {
		return reservationID;
	}
	public void setReservationID(Integer reservationID) {
		this.reservationID = reservationID;
	}
	public String getCustomerDetails() {
		return customerDetails;
	}
	public void setCustomerDetails(String customerDetails) {
		this.customerDetails = customerDetails;
	}
	public String getRouteDetails() {
		return routeDetails;
	}
	public void setRouteDetails(String routeDetails) {
		this.routeDetails = routeDetails;
	}
	public LocalDate getBookingDate() {
		return bookingDate;
	}
	public void setBookingDate(LocalDate bookingDate) {
		this.bookingDate = bookingDate;
	}
	public LocalDate getJourneyDate() {
		return journeyDate;
	}
	public void setJourneyDate(LocalDate journeyDate) {
		this.journeyDate = journeyDate;
	}
	public String getVehicleDetails() {
		return vehicleDetails;
	}
	public void setVehicleDetails(String vehicleDetails) {
		this.vehicleDetails = vehicleDetails;
	}
	public String getDriverDetails() {
		return driverDetails;
	}
	public void setDriverDetails(String driverDetails) {
		this.driverDetails = driverDetails;
	}
	public String getBookingStatus() {
		return bookingStatus;
	}
	public void setBookingStatus(String bookingStatus) {
		this.bookingStatus = bookingStatus;
	}
	public double getTotalFare() {
		return totalFare;
	}
	public void setTotalFare(double totalFare) {
		this.totalFare = totalFare;
	}
	public String getBoardingPoint() {
		return boardingPoint;
	}
	public void setBoardingPoint(String boardingPoint) {
		this.boardingPoint = boardingPoint;
	}
	public String getDropPoint() {
		return dropPoint;
	}
	public void setDropPoint(String dropPoint) {
		this.dropPoint = dropPoint;
	}
	public BookingDetails(Integer reservationID, String customerDetails, String routeDetails, LocalDate bookingDate,
			LocalDate journeyDate, String vehicleDetails, String driverDetails, String bookingStatus, double totalFare,
			String boardingPoint, String dropPoint) {
		super();
		this.reservationID = reservationID;
		this.customerDetails = customerDetails;
		this.routeDetails = routeDetails;
		this.bookingDate = bookingDate;
		this.journeyDate = journeyDate;
		this.vehicleDetails = vehicleDetails;
		this.driverDetails = driverDetails;
		this.bookingStatus = bookingStatus;
		this.totalFare = totalFare;
		this.boardingPoint = boardingPoint;
		this.dropPoint = dropPoint;
	}
	@Override
	public String toString() {
		return "BookingDetails [reservationID=" + reservationID + ", customerDetails=" + customerDetails
				+ ", routeDetails=" + routeDetails + ", bookingDate=" + bookingDate + ", journeyDate=" + journeyDate
				+ ", vehicleDetails=" + vehicleDetails + ", driverDetails=" + driverDetails + ", bookingStatus="
				+ bookingStatus + ", totalFare=" + totalFare + ", boardingPoint=" + boardingPoint + ", dropPoint="
				+ dropPoint + "]";
	}
	
	public BookingDetails() {
		// TODO Auto-generated constructor stub
	}
	
	

}
