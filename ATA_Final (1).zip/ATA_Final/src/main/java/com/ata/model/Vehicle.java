package com.ata.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Vehicle {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer vId;
	@Column(nullable = false)
	private String Name;
	@Column(nullable = false)
	private String Types;
	@Column(nullable = false)
	private String AC;
	@Column(nullable = false)
	private String RegisterNo;
	@Column(nullable = false)
	private Integer Seating;
	@Column(nullable = false)
	private double Kmprice;
	public Integer getvId() {
		return vId;
	}
	public void setvId(Integer vId) {
		this.vId = vId;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getTypes() {
		return Types;
	}
	public void setTypes(String types) {
		Types = types;
	}
	public String getAC() {
		return AC;
	}
	public void setAC(String aC) {
		AC = aC;
	}
	public String getRegisterNo() {
		return RegisterNo;
	}
	public void setRegisterNo(String registerNo) {
		RegisterNo = registerNo;
	}
	public Integer getSeating() {
		return Seating;
	}
	public void setSeating(Integer seating) {
		Seating = seating;
	}
	public double getKmprice() {
		return Kmprice;
	}
	public void setKmprice(double kmprice) {
		Kmprice = kmprice;
	}
	@Override
	public String toString() {
		return "Vehicle [vId=" + vId + ", Name=" + Name + ", Types=" + Types + ", AC=" + AC + ", RegisterNo="
				+ RegisterNo + ", Seating=" + Seating + ", Kmprice=" + Kmprice + "]";
	}
	public Vehicle( String name, String types, String aC, String registerNo, Integer seating, double kmprice) {
		super();
		this.vId = vId;
		Name = name;
		Types = types;
		AC = aC;
		RegisterNo = registerNo;
		Seating = seating;
		Kmprice = kmprice;
	}
	public Vehicle() {
		super();
	}
	
	
	
}
